﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

using System;
using System.Runtime.CompilerServices;


namespace Project8
{
    public class bal
    {
        bool 
        
        public Rectangle balBoundingBox
        {
            get
            {
                Rectangle balspriteBounds = bal.Bounds;
                balspriteBounds.Offset(balPosition - balOrigin);
                return balspriteBounds;
            }
        }
        public override void Reset()
        {
            base.Reset();
            balPosition = new Vector2(Game1.background.Width / 2, background.Height / 2);
            int random = Random.Next(0, 3);
            if (random == 0)
                velocity = new Vector2(-250, -50);
            else if (random == 1)
                velocity = new Vector2(-250, 50);
            else if (random == 2)
                velocity = new Vector2(250, -50);
            else
                velocity = new Vector2(250, 50);

        }
    }
}
