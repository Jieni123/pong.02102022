﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

using System;
using System.Runtime.CompilerServices;

namespace project8
{
   class Game1 : Game
    {
        GraphicsDeviceManager _graphics;
        SpriteBatch _spriteBatch;
        Texture2D redwonscherm, bluewonscherm, startscherm, background; 
        Random Random = new Random();
       
        int LivesPlayer1;
        int LivesPlayer2;
      
        SoundEffect quack;


        enum GameState { Start, Play, End };
        GameState pong;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = false;
            LivesPlayer1 = 5;
            LivesPlayer2 = 5;
        }

        //als het aantal levens van 1 van de spelers 0 is eindigt het spel
        bool Einde
        { get { return LivesPlayer1 <= 0 || LivesPlayer2 <= 0; } }
        public void LoseLifePlayer1()
        { LivesPlayer1--; }
        public void LoseLifePlayer2()
        { LivesPlayer2--; }
        protected override void Initialize()
        {
            // de grootte van het scherm
            _graphics.PreferredBackBufferWidth = 1000;
            _graphics.PreferredBackBufferHeight = 500;
            _graphics.ApplyChanges();

            base.Initialize();
        }
        protected override void LoadContent()
        {
            pong = GameState.Start;

            //het laden van de sound en soundeffects
            MediaPlayer.Play(Content.Load<Song>("bgmusic"));
            quack = Content.Load<SoundEffect>("quack.mp3");

            // het laden van de sprites
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            background = Content.Load<Texture2D>("background");
            redwonscherm = Content.Load<Texture2D>("redwonplayagain");
            bluewonscherm = Content.Load<Texture2D>("bluewonplayagain");
            startscherm = Content.Load<Texture2D>("startscreen");


            // de origin van de sprites



            //kiest een "random" richting

        }
        public Rectangle rodeSpelerBoundingBox
        {
            get
            {
                Rectangle rodeSpelerspriteBounds = rodeSpeler.Bounds;
                rodeSpelerspriteBounds.Offset(Spelers.rodeSpelerPosition - rodeSpelerOrigin);
                return rodeSpelerspriteBounds;
            }
        }
        public Rectangle blauweSpelerBoundingBox
        {
            get
            {
                Rectangle blauweSpelerspriteBounds = blauweSpeler.Bounds;
                blauweSpelerspriteBounds.Offset(blauweSpelerPosition - blauweSpelerOrigin);
                return blauweSpelerspriteBounds;
            }
        }
        public void start()
        {
            bal.balReset();
            SpelersReset();
            pong = GameState.Play;
            LivesPlayer1 = 5;
            LivesPlayer2 = 5;
        }
        protected override void Update(GameTime gameTime)
        {
            PlayerInput();
            //als einde (dus het aantal levens zijn 0) dan opent het eindscherm
            if (Einde == true)
            {
                pong = GameState.End;
            }
            //als je op spatie drukt start het spel/begint het opnieuw
            if ((pong == GameState.Start || pong == GameState.End))
            {
                if (currentKeyboardState.IsKeyDown(Keys.Space))
                {
                    start();
                }
            }
            if (pong == GameState.Play)
            //het bewegen van de bal    
            {
                balPosition += velocity * (float)gameTime.ElapsedGameTime.TotalSeconds;
                //voorkomen dat de blauwe en rode speler van het scherm afgaan
                if (blauweSpelerPosition.Y > (500 - (blauweSpeler.Height / 2)))
                    blauweSpelerPosition.Y = (500 - (blauweSpeler.Height / 2));
                if (blauweSpelerPosition.Y < (blauweSpeler.Height / 2))
                    blauweSpelerPosition.Y = (blauweSpeler.Height / 2);

                if (rodeSpelerPosition.Y > (500 - (rodeSpeler.Height / 2)))
                    rodeSpelerPosition.Y = (500 - (rodeSpeler.Height / 2));
                if (rodeSpelerPosition.Y < (rodeSpeler.Height / 2))
                    rodeSpelerPosition.Y = (rodeSpeler.Height / 2);

                //het bouncen van de bal tegen de boven en onderkant
                if (balPosition.Y <= 0)
                    velocity.Y *= -1;
                if (balPosition.Y >= 500)
                    velocity.Y *= -1;
                //bal gaat terug naar het begin als hij tegen de zijkanten aankomt
                if (balPosition.X <= 0)
                    LoseLifePlayer1();
                if (balPosition.X <= 0)
                    balReset();
                if (balPosition.X >= 1000)
                    LoseLifePlayer2();
                if (balPosition.X >= 1000)
                    balReset();


                //bal bouncet terug en versnelt als hij een speler raakt

                if (balBoundingBox.Intersects(rodeSpelerBoundingBox))
                {
                    quack.Play();
                    /* float Angle;
                     float speed = velocity.X * velocity.X + velocity.Y * velocity.Y + 50;
                     if (balOrigin.Y > rodeSpelerOrigin.Y)
                         Angle = (balOrigin.Y - rodeSpelerOrigin.Y)/((1/2)*rodeSpeler.Height)* ((1/2)*(float)Math.PI);
                     else
                         Angle = (rodeSpelerOrigin.Y - balOrigin.Y)/((1/2)*rodeSpeler.Height)* ((1/2)*(float)Math.PI);

                     if (velocity.Y > 0)
                              velocity.Y = - (speed * (float) Math.Sin(Angle));
                         else
                             velocity.Y = (speed* (float) Math.Sin(Angle));

                     if( velocity.X > 0)
                     {
                        velocity.X = - (speed * (float)Math.Cos(Angle));
                     }
                     else
                     {
                        velocity.X =speed * (float)Math.Cos(Angle);
                     }*/

                    velocity.X *= -1;

                    if (velocity.X > 0)
                        velocity.X += 30;
                    else
                        velocity.X -= 30;
                    if (velocity.Y > 0)
                        velocity.Y += 30;
                    else
                        velocity.Y -= 30;


                }

                if (balBoundingBox.Intersects(blauweSpelerBoundingBox))
                {
                    quack.Play();
                    velocity.X *= -1;
                    if (velocity.X > 0)
                        velocity.X += 30;
                    else
                        velocity.X -= 30;
                    if (velocity.Y > 0)
                        velocity.Y += 30;
                    else
                        velocity.Y -= 30;


                }
            }


            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {

            _spriteBatch.Begin();
            if (pong == GameState.Start)
            {
                GraphicsDevice.Clear(Color.White);
                _spriteBatch.Draw(startscherm, Vector2.Zero, Color.White);
            }


            if (pong == GameState.End)
            {
                GraphicsDevice.Clear(Color.White);
                if (LivesPlayer1 == 0)
                    _spriteBatch.Draw(redwonscherm, Vector2.Zero, Color.White);
                else
                    _spriteBatch.Draw(bluewonscherm, Vector2.Zero, Color.White);

            }
            if (pong == GameState.Play)
            {
                GraphicsDevice.Clear(Color.White);
                _spriteBatch.Draw(background, Vector2.Zero, Color.White);
                _spriteBatch.Draw(bal, balPosition - balOrigin, Color.White);
                _spriteBatch.Draw(blauweSpeler, blauweSpelerPosition - blauweSpelerOrigin, Color.White);
                _spriteBatch.Draw(rodeSpeler, rodeSpelerPosition - rodeSpelerOrigin, Color.White);
                for (int Die1 = 0; Die1 < LivesPlayer1; Die1++)
                { _spriteBatch.Draw(Heart1, new Vector2(Die1 * Heart1.Width + 50, 0), Color.White); }
                for (int Die2 = 0; Die2 < LivesPlayer2; Die2++)
                { _spriteBatch.Draw(Heart2, new Vector2(Die2 * Heart2.Width + (background.Width - 100), 0), Color.White); }
            }
            _spriteBatch.End();
            //telkens als de bal bij de y as komt zal er 1 hartje weggaan

            base.Draw(gameTime);

        }
    }
}