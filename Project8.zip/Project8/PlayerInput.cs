﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

using System;
using System.Runtime.CompilerServices;


namespace Project8
{
    internal class PlayerInput
    {
        KeyboardState currentKeyboardState, previousKeyboardState;
  


        public void SpelersReset()
        {
            rodeSpelerPosition = new Vector2(background.Width - (blauweSpeler.Width / 2), background.Height / 2);
            blauweSpelerPosition = new Vector2((blauweSpeler.Width / 2), background.Height / 2);
        }
        public bool KeyPressed(Keys h)
        {
            return currentKeyboardState.IsKeyDown(h) && previousKeyboardState.IsKeyUp(h);
        }
        public void playerInput()
        {
            // escape gebruiken om uit het spel te gaan
            if (Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
            // het ophalen van de staat van het keyboard
            previousKeyboardState = currentKeyboardState;
            currentKeyboardState = Keyboard.GetState();


            if (Project8 == GameState.Play)
            {
                //het op en neer bewegen van de blauwe & rode speler
                if (currentKeyboardState.IsKeyDown(Keys.W))
                    blauweSpelerPosition.Y -= 10;
                if (currentKeyboardState.IsKeyDown(Keys.S))
                    blauweSpelerPosition.Y += 10;


                if (currentKeyboardState.IsKeyDown(Keys.Up))
                    rodeSpelerPosition.Y -= 10;
                if (currentKeyboardState.IsKeyDown(Keys.Down))
                    rodeSpelerPosition.Y += 10;
            }
        }


    }
}
