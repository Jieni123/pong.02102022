﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

using System;
using System.Runtime.CompilerServices;


namespace Project8
{
    internal class Spelers
    {
        Texture2D rodeSpeler, blauweSpeler,background;
        Vector2 rodeSpelerPosition, blauweSpelerPosition;

        public Spelers(ContentManager Content) 
            : base (Content, "rodeSpeler", "blauweSpeler")
        { rodeSpelerPosition = new Vector2(background.Width - (blauweSpeler.Width / 2), background.Height / 2); }
            public void SpelersReset()
        {
            rodeSpelerPosition = new Vector2(background.Width - (blauweSpeler.Width / 2), background.Height / 2);
            blauweSpelerPosition = new Vector2((blauweSpeler.Width / 2), background.Height / 2);
        }
    }
}
