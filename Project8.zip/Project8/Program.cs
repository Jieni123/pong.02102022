﻿
using var game = new project8.Game1();
game.Run();
